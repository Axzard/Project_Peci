# kotoran beras > 2023-12-16 9:02pm
https://universe.roboflow.com/haydar-qs/kotoran-beras

Provided by a Roboflow user
License: CC BY 4.0

